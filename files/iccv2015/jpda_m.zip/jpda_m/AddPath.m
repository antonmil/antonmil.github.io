%% Add Path 

addpath('C:\gurobi605\win64\matlab\');
% pwdd= cd('..');
addpath(genpath(pwd))
% cd(pwdd);