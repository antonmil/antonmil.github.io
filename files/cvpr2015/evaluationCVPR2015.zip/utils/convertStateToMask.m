function res=convertStateToMask(stateInfo,sp_labels,frames)
% take final labeling and create segmentation mask



if nargin<3
    frames=1:stateInfo.F;
end
Fmax=max(frames);
F=length(frames);

sp_labels=sp_labels(:,:,1:Fmax);

% F=20;
[h,w,f]=size(sp_labels);
res=zeros(h,w,F,'uint16');

if exist('SPPerFrame','var') && length(SPPerFrame)==Fmax
else
    SPPerFrame=[];
    for t=1:Fmax
        SPPerFrame(t)=numel(unique(sp_labels(:,:,t)));
    end
end

tcnt=0;
for t=frames
    tcnt=tcnt+1;
    fprintf('.');
    thisF=sp_labels(:,:,t);
    segs=unique(thisF(:))';
    
    
    Io=zeros(h,w,'uint16');
    
    if t==1, lbegin=0;
    else lbegin=sum(SPPerFrame(1:t-1));
    end
    
    cnt=lbegin;
    for s=segs
        cnt=cnt+1;
        l=stateInfo.splabeling(cnt);
        if l==stateInfo.bglabel, l=0; end
        
        [u,v]=find(thisF==s);
        imind=sub2ind(size(thisF),u,v);
        Io(imind)=uint16(l);
        
    end
    res(:,:,tcnt)=Io;    
    
end
fprintf('\n');

end