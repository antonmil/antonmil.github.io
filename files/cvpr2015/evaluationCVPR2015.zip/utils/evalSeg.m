function [ce, prce, extrobj, pr, rc, os, prN, rcN]=evalSeg(gt, res)
% evaluate video segmentation
% INPUT
%   gt -    ground truth segmentation
%           [H x W x F] matrix
%   res -   result segmentation
%           [H x W x F] matrix
% 
% OUTPUT
%   ce      clustering error (wrongly labeled pixels)
%   prce    per-region clustering error (wrong pixels per gt mask)
%   pr      precision (unused)
%   rc      recall (unused)
%   os      over-segmenation (number of unique labels per gt mask)
%   prN     per-frame precision (TP / (FP + TP))
%   rcN     per-frame recall (TP / GT)

assert(all(size(gt)==size(res)),'gt and result must have equal dimensions');

% what are our dimensions?
[H,W,F]=size(gt);
imsize=[H, W];

% initialize output
ce=0;
prce=0;
pr=0;
rc=0;
os=0;


% shift labels to positive numbers: 1,2,...
% minlab=min(gt(:)); if minlab<1, gt=gt-minlab+1; end
% minlab=min(res(:)); if minlab<1, res=res-minlab+1; end

% make bg label last instead of zero
bgGT=max(gt(:))+1;bgRes=max(res(:))+1;
gt(gt==0)=bgGT;res(res==0)=bgRes;


gtRegions=unique(gt(:));resRegions=unique(res(:));
nGTReg=numel(gtRegions); nResReg=numel(resRegions);

gt=double(gt); res=double(res);
% count 1...N,BG
cnt=0;
for r=gtRegions'
    cnt=cnt+1;
    ind=(find(gt(:)==r));

    gt(ind) = -cnt;
end
gt=abs(gt);

cnt=0;
for r=resRegions'
    cnt=cnt+1;
    res(find(res(:)==r))= -cnt;
end
res=abs(res);
% gt=uint16(gt); res=uint16(res);

gtRegions=unique(gt(:));
resRegions=unique(res(:));


%% remove BG
% gtRegions=gtRegions(1:end-1);
% resRegions=resRegions(1:end-1);


nGTReg=numel(gtRegions);
nResReg=numel(resRegions);

assert(all(sort(gtRegions)'==(1:nGTReg)),'gt reg missing?');
assert(all(sort(resRegions)'==(1:nResReg)),'res reg missing?');

fprintf('GT Regions: \t%d\n',nGTReg);
fprintf('Res Regions: \t%d\n',nResReg);

isectMat = zeros(nGTReg,nResReg);   % intersection matrix

rcN=zeros(F,nGTReg-1);  % naive recall (per frame FG coverage)
prN=zeros(F,1);  % naive precision (per frame BG classified as FG)
gtMask=zeros(F,nGTReg); % count number of pixels per mask
resMask=zeros(F,nResReg); % count number of pixels per result segment



for t=1:F
%     fprintf('.');
    thisGT=gt(:,:,t);
    thisRes=res(:,:,t);

    segsGT=unique(thisGT(:))';
    segsRes=unique(thisRes(:))';
    
%     segsGT
%     segsRes
    
    cntgt=0;
    cntres=0;
    
    thisIsectMat=zeros(size(isectMat));
    for s=segsGT
        cntgt=cntgt+1;
%         if s>size(isectMat,1), continue; end
        
        [u,v]=find(thisGT==s);
        imind=sub2ind(imsize,u,v);
        
        gtMask(t,s) = numel(imind);

        
        for sr=segsRes
%             if sr>size(isectMat,2), continue; end
            [u,v]=find(thisRes(imind)==sr);
            thisIsectMat(s,sr)=numel(u);
            isectMat(s,sr)=isectMat(s,sr)+numel(u);
            
        end
        
    end
    
    for sr=segsRes
        [u,~]=find(thisRes==sr);
        resMask(t,sr) = numel(u);
        
    end
    
    isectNoBG=thisIsectMat(1:end-1,1:end-1);    
    
    rcN(t,:) = sum(isectNoBG,2)';
    prN(t) = sum(thisIsectMat(1:end-1,end));
end
fprintf('\n');

isectMatAll=isectMat;
isectMat=-isectMat;
isectMat(find(~isectMat))=Inf;


% isectMat(3,:)=Inf;
% isectMat


% Hungarian one to one
% [Matching, Cost]=Hungarian(isectMat);
% [u,v]=find(Matching);

% greedy n tracks to one gt
% isectMat
[u,v]=min(isectMat,[],2);
u=gtRegions;
[ur,vr]=min(isectMat,[],1);
% vr=vr';
ur=resRegions';
% nonassgn=find(u==Inf);
% for g=gtRegions'        
%     if all(isinf(isectMat(g,1:end-1)))
%         v(g)=size(isectMat,2);        
%     end
% end
% [u';v']
% ur'
% vr'
Matching=zeros(size(isectMat));
mind=sub2ind(size(isectMat),u,v);
Matching(mind)=1;

Matching2=zeros(size(isectMat));
% size(isectMat)
% ur
% vr
mind=sub2ind(size(isectMat),vr,ur);
Matching2(mind)=1;

% Matching
% Matching2

% u(find(u==bgGT))=0;v(find(v==bgRes))=0;
% fprintf('GT:\t');fprintf('%3d',u);fprintf('\n');
% fprintf('Res:\t');fprintf('%3d',v);fprintf('\n');
% fprintf('GT:\t');fprintf('%3d',vr);fprintf('\n');
% fprintf('Res:\t');fprintf('%3d',ur);fprintf('\n');
% isectMat

% now we have an assignment
% compute metrics

% over segmentation
os = mean(sum(Matching,2));
os2 = mean(sum(Matching,1));

% naive per-frame precision and recall
% sum(sum(gtMask(:,1:end-1)))
totalFG=sum(rcN(:));    % correctly classified as FG
totalGT = numel(find(gt(:)~=bgGT)); % ground truth FG pixels
totalFP = sum(prN); % falsely classified as target

prN = 100 *  totalFG / (totalFP + totalFG);
rcN = 100 * totalFG / totalGT;

% average clustering error
% isectMatAll
perMask=sum(gtMask,1);     % number of pixels per mask
perRegion=sum(resMask,1);  % number of pixels per region

wrongPixels=0;
extrobj=0;
for g=gtRegions(1:end)'
%     if v(g) == size(isectMatAll,2)
%         wrongPixels=wrongPixels + perMask(g);
%         wrongPixPerMask(g)=1;
%     else

        wrongPixels = wrongPixels+ sum(isectMatAll(g,[1:v(g)-1 v(g)+1:end]));
        wrongPixPerMask(g) = sum(isectMatAll(g,[1:v(g)-1 v(g)+1:end]))/perMask(g);
%     end
%     wrongPixels
%     wrongPixPerMask
%     pause

%     [g v(g)]
%     sum(isectMatAll(g,[1:v(g)-1 v(g)+1:end]))
%     wrongPixPerMask
%     perMask(g)
%     pause

    if wrongPixPerMask(g) < .1 && v(g) ~= size(isectMatAll,2)
        extrobj=extrobj+1;
%         g
    end
    
end
totalPix=H*W*F;
ce=100*wrongPixels/totalPix;
prce=100*mean(wrongPixPerMask);
% wrongPixPerMask


wrongPixels2=0;
extrobj2=0;
% second attempt
for r=resRegions(1:end)'
    wrongPixels2 = wrongPixels2 + sum(isectMatAll([1:vr(r)-1 vr(r)+1:end],r));

    wrongPixPerRegion(r) = sum(isectMatAll([1:vr(r)-1 vr(r)+1:end],r))/perRegion(r);

    if wrongPixPerRegion(r) < .1
        extrobj2=extrobj2+1;
%         g
    end    
end
wrongPixPerRegion;
ce2=100*wrongPixels2/totalPix;
prce2=100*mean(wrongPixPerRegion);
% wrongPixPerRegion

% for t=1:F
%     fprintf('.');
%     thisGT=gt(:,:,t);
%     thisRes=res(:,:,t);
% 
%     segsGT=unique(thisGT(:))';
%     segsRes=unique(thisRes(:))';
%     
%     cntgt=0;
%     cntres=0;
%     
%     for s=segsGT
%         cntgt=cntgt+1;
%         
%         [u,v]=find(thisGT==s);
%         imind=sub2ind(imsize,u,v);
% 
%         
%         for sr=segsRes
%             [u,v]=find(thisRes(imind)==sr);
%             isectMat(s,sr)=isectMat(s,sr)+numel(u);
%             
%         end
%         
%     end
% end
% fprintf('\n');

%%
metrInfo={'CE','PRCE','over-seg','ex. obj.'};
for m=1:length(metrInfo)
    fprintf('%10s |',char(metrInfo{m}));
end
% fprintf('\n');
% 
% fprintf('%10g |',[ce,prce,os,extrobj,prN,rcN]);
% fprintf('\n');

%%%%%
fprintf('\n');

fprintf('%10.2f |',[ce2,prce2,os2,extrobj2]);
fprintf('\n');


end