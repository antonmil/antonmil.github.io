function allmets=evalDataset(infos,gtInfos,allscen,evopts,crop)
% evaluate and print out all sequences and the mean

allmets=zeros(length(allscen),14);
scnt=0;
opt.track3d=0;
if evopts.eval3d, opt.track3d=1; end

for scenario=allscen
    scnt=scnt+1;
    gtInfo=gtInfos(scenario).gtInfo;
    stateInfo=infos(scenario).stateInfo;

    if crop
        sceneInfo.trackingArea=[-14069.6, 4981.3, -14274.0, 1733.5];
        if scenario==42, sceneInfo.trackingArea=[-19, 12939, -48, 10053]; end

        stateInfo=cutStateToTrackingArea(stateInfo,sceneInfo,opt);
        gtInfo=cutGTToTrackingArea(gtInfo,sceneInfo);
    end

    [metrics, metricsInfo, ~]=CLEAR_MOT(gtInfo,stateInfo,evopts);
    printMetrics(metrics,metricsInfo,scnt==1);
    
    allmets(scnt,:)=metrics;
end
fprintf(' ----------------------------------------------------------------------\n');
meanmets=mean(allmets,1); meanmets(4:11)=round(meanmets(4:11));
printMetrics(meanmets,metricsInfo,0);