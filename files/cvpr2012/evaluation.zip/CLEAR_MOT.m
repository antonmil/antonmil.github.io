function [MOTA, MOTP, ma, fpa, mmea, idsw, missed, falsepositives, idswitches, ...
    alltracked, allfalsepos, MT, PT, ML, recall, precision, fafrm, FRA, MOTAL, alld] =...
    CLEAR_MOT(Xgt, Ygt, X, Y,td)
% CLEAR MOT evaluation
%
% parameters
% in
%
% Xgt, Ygt
% ground truth positions on the ground plane
% row i column j corresponds to frame i target number j
% zero (0) means that target does not exist
%
% X, Y
% position of the solution to be evaluated
% Xgt, Ygt, X, Y should all have equal number of rows
% 
% td
% threshold for hit/miss
% if not provided, it is set to 1000 (=1m for PETS e.g.)
%
%
% parameters
% out
% MOTA	- Multi-object tracking accuracy in [0,1]
% MOTP	- Multi-object tracking precision in [0,1]
% ma	- missed targets per ground truth targets (usually not used)
% fpa	- false positives per ground truth targets (usually not used)
% mmea	- id switches per ground truth targets (usually not used)
% idsw	- id switches per number of targets per frame (usually not used)
% missed	- number of missed targets
% falsepositives- number of false positives
% idswitches	- number of id switches
% alltracked	- details about tracked targets (not really used)
% allfalsepos	- details about false positives (not really used)
% MT, PT, ML	- number of mostly tracked, partially tracked and mostly lost trajectories
% recall	- recall = percentage of detected targets
% precision	- precision = percentage of correctly detected targets
% fafrm		- number of false alarms per frame
% FRA       - number of fragmentations
% MOTAL	- Multi-object tracking accuracy in [0,1] with log10(idswitches)
% alld  - all distances to gt
%
% @author Anton Andriyenko
%


%     curtracked
%     alltrackers=find(X(t,:))
%     allgt=find(Xgt(t,:))
%     mappedtrackers=intersect(M(t,find(M(t,:))),alltrackers)
%     falsepositives=setdiff(alltrackers,mappedtrackers)
%     
%     pause

if size(Xgt,1) > size(X,1)
    Xgt=Xgt(1:size(X,1),:);Ygt=Ygt(1:size(Y,1),:);
elseif size(Xgt,1) < size(X,1)
    X=X(1:size(Xgt,1),:);Y=Y(1:size(Ygt,1),:);
end

[Fgt Ngt]=size(Xgt);
[F N]=size(X);

alltracked=zeros(F,Ngt);
allfalsepos=zeros(F,N);

if ~N
    MOTA=0;
    MOTP=0;
    ma=1;
    fpa=0;
    mmea=0;
    idsw=0;
    missed=numel(find(Xgt));
    falsepositives=0;
    idswitches=0;
    MT=0;
    PT=0;
    ML=size(Xgt,2);
    recall=0;
    precision=0;
    fafrm=0;
    FRA=0;
    return;
end

M=zeros(F,Ngt);

if nargin<=4
    td=1000; %threshold in mm
end

mme=zeros(1,F); % ID Switchtes
c=zeros(1,F);   % matches found
fp=zeros(1,F);  % false positives
m=zeros(1,F);   % misses = false negatives
g=zeros(1,F);
d=zeros(F,Ngt);  % all distances;

for t=1:F
    
    g(t)=numel(find(Xgt(t,:)));
    if t>1
        mappings=find(M(t-1,:));
        
        for map=mappings
            if Xgt(t,map) && X(t,M(t-1,map)) && ...
                    norm([Xgt(t,map) Ygt(t,map)]-[X(t,M(t-1,map)) Y(t,M(t-1,map))])<=td
                M(t,map)=M(t-1,map);
            end
        end
    end
    
    alldist=Inf*ones(Ngt,N);
    GTsNotMapped=find(~M(t,:) & Xgt(t,:));
    
    %     EsNotMapped=find(X(t,:));
    EsNotMapped=setdiff(find(X(t,:)),M(t,:));
    mindist=0;
    while mindist < td && numel(GTsNotMapped)>0 && numel(EsNotMapped)>0
        % GTsNotMapped
        % EsNotMapped
        %     numel(GTsNotMapped)>0
        for o=GTsNotMapped
            GT=[Xgt(t,o) Ygt(t,o)];
            for e=EsNotMapped
                E=[X(t,e) Y(t,e)];
                alldist(o,e)=norm(GT-E);
            end
        end
        [mindist cind]=min(alldist(:));
        %         alldist
        %         [mindist cind]
        %         pause

        if mindist <= td
            [u v]=ind2sub(size(alldist),cind);
            M(t,u)=v;
            %             alldist(cind)=Inf;
            alldist(:,v)=Inf;
            GTsNotMapped=find(~M(t,:) & Xgt(t,:));
            EsNotMapped=setdiff(find(X(t,:)),M(t,:));
        else
            %             [u v]=ind2sub(size(alldist),cind)
        end
        
        
    end
    
    curtracked=find(M(t,:));
    
    
%     t

%     curtracked
    alltrackers=find(X(t,:));
%     allgt=find(Xgt(t,:));
    mappedtrackers=intersect(M(t,find(M(t,:))),alltrackers);
    falsepositives=setdiff(alltrackers,mappedtrackers);
    
%     alltracked(t,1:length(curtracked))=curtracked;
    alltracked(t,:)=M(t,:);
%     M(t,:)
    allfalsepos(t,1:length(falsepositives))=falsepositives;
%     
%     pause
    
    %%  mismatch errors
    if t>1
        for ct=curtracked
            lastnotempty=find(M(1:t-1,ct),1,'last');
            if Xgt(t-1,ct) && ~isempty(lastnotempty) && M(t,ct)~=M(lastnotempty,ct)
                mme(t)=mme(t)+1;
            end
        end
    end
    
    %     %%  mismatch errors (also start tracking and each frag counts)
    %     if t>1
    %         for ct=curtracked
    %             if Xgt(t-1,ct) && M(t,ct)~=M(t-1,ct)
    %                 mme(t)=mme(t)+1;
    %             end
    %         end
    %     end
    
    
    c(t)=numel(curtracked);
    %     [t c(t)]
    for ct=curtracked
        eid=M(t,ct);
        d(t,ct)=norm([Xgt(t,ct) Ygt(t,ct)]-[X(t,eid) Y(t,eid)]);
    end
    
    
    fp(t)=numel(find(X(t,:)))-c(t);
    %     X(t,:)
    %     pause
    
    %     X(t,:)
    %     c(t)
    %     pause
    m(t)=g(t)-c(t);
    
    
end
%
%     [c' fp' m' g']
%     M
%     pause

% [(19:22)' M(19:22,:)]
% [(1:F)' M mme' g']
missed=sum(m);
falsepositives=sum(fp);
idswitches=sum(mme);
%
% sum(m)
% sum(fp)
% log10(sum(mme)+1)
% sum(g)

MOTP=1-sum(sum(d))/sum(c)/td; % avg distance to [0,1]

% MOTP=sum(sum(d))/sum(c); % avg distance
MOTAL=1-((sum(m)+sum(fp)+log10(sum(mme)+1))/sum(g));
MOTA=1-((sum(m)+sum(fp)+(sum(mme)))/sum(g));
ma=sum(m)/sum(g);
fpa=sum(fp)/sum(g);
mmea=sum(mme)/sum(g);
idsw=sum(mme)/Ngt/Fgt;
recall=sum(c)/sum(g);
precision=sum(c)/(sum(fp)+sum(c));
fafrm=sum(fp)/Fgt;


%single precision
MOTA=single(MOTA);
MOTP=single(MOTP);
ma=single(ma);
fpa=single(fpa);
mmea=single(mmea);
idsw=single(idsw);
missed =single(missed);
falsepositives=single(falsepositives);
idswitches=single(idswitches);

%% MT PT ML
MTstatsa=zeros(1,Ngt);
for i=1:Ngt
    gtframes=find(Xgt(:,i));
    gtlength=length(gtframes);
    gttotallength=numel(find(Xgt(:,i)));
    trlengtha=numel(find(alltracked(gtframes,i)>0));    
    
    if gtlength/gttotallength >= 0.8 && trlengtha/gttotallength < 0.2
        MTstatsa(i)=3;
    elseif t>=find(Xgt(:,i),1,'last') && trlengtha/gttotallength <= 0.8
        MTstatsa(i)=2;
    elseif trlengtha/gttotallength >= 0.8
        MTstatsa(i)=1;
    end
end
MT=numel(find(MTstatsa==1));PT=numel(find(MTstatsa==2));ML=numel(find(MTstatsa==3));

%% fragments
fr=zeros(1,Ngt);
for i=1:Ngt
    b=alltracked(find(alltracked(:,i),1,'first'):find(alltracked(:,i),1,'last'),i);
    b(~~b)=1;
    fr(i)=numel(find(diff(b)==-1));
end
FRA=sum(fr);
alld=d;
end
