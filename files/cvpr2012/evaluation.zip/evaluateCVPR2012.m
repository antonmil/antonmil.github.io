%% evaluate results for CVPR 2012 paper


%%%%%%%%%%%% TUD Stadtmitte

% load result and GT
load('data/TUD-Stadtmitte-cropped.mat');

% compute metrics
[M, P, ma, fpa, mmea, idsw, mm, fp, is, at, afp, MT, PT, ML, rc, pc, faf, FM, MOTAL, alld]= ...
    CLEAR_MOT(Xgt, Ygt, X, Y,1000); M=M*100; P=P*100; MOTAL=MOTAL*100;

% print infos
fprintf('Evaluating TUD Stadtmitte on ground plane...\n');
fprintf(' sc  time| Recl Prcn  FAR| MT PT ML|  FPR  FNR  FP  FN  ID  FM  err| MOTA MOTP MOTL\n');
fprintf('%3i %5.1f|%5.1f%5.1f%5.2f|%3i%3i%3i|%5.1f%5.1f%4i%4i%4i%4i%5i|%5.1f %4.1f %4.1f\n\n', ...
    scenario,0,rc*100,pc*100,faf,MT,PT,ML,100*fpa,100*ma,fp,mm,is,FM,mm+fp+is,M,P,MOTAL);


%%%%%%%%%%%% S2L1

% load result and GT
load('data/PETS-S2L1-cropped.mat');

% compute metrics
[M, P, ma, fpa, mmea, idsw, mm, fp, is, at, afp, MT, PT, ML, rc, pc, faf, FM, MOTAL, alld]= ...
    CLEAR_MOT(Xgt, Ygt, X, Y,1000); M=M*100; P=P*100; MOTAL=MOTAL*100;


% print infos
fprintf('Evaluating PETS S2.L2 on ground plane...\n');
fprintf(' sc  time| Recl Prcn  FAR| MT PT ML|  FPR  FNR  FP  FN  ID  FM  err| MOTA MOTP MOTL\n');
fprintf('%3i %5.1f|%5.1f%5.1f%5.2f|%3i%3i%3i|%5.1f%5.1f%4i%4i%4i%4i%5i|%5.1f %4.1f %4.1f\n', ...
    scenario,0,rc*100,pc*100,faf,MT,PT,ML,100*fpa,100*ma,fp,mm,is,FM,mm+fp+is,M,P,MOTAL);

